#include "../include/embserve.h"

#ifndef SERVICE_NAME
#error "Define SERVICE_NAME"
#endif

extern void embserve_output_impl(const char * tag, embserve_io_t * output);

void embserve_output(embserve_io_t * output) {
    embserve_output_impl(SERVICE_NAME, output);
}