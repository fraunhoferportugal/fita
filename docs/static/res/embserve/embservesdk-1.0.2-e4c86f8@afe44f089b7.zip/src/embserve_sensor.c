#include "../include/embserve_sensor.h"

extern int embserve_get_sensor_impl(const char * tag, embserve_sensor_type_t type, int * sensor_id);
extern int embserve_get_sensor_data_impl(const char * tag, int sensor_id, embserve_sensor_data_t * sensor_data);

int embserve_get_sensor(embserve_sensor_type_t type, int * sensor_id) {
    return embserve_get_sensor_impl(SERVICE_NAME, type, sensor_id);
}

int embserve_get_sensor_data(int sensor_id, embserve_sensor_data_t * sensor_data) {
    return embserve_get_sensor_data_impl(SERVICE_NAME, sensor_id, sensor_data);
}