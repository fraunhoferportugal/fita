#include "../include/i2s.h"

#ifndef SERVICE_NAME
#error "Define SERVICE_NAME"
#endif

extern const void * embserve_i2s_get_impl(const char * tag, uint8_t idx);
extern int embserve_i2s_configure_impl(const char * tag, const void *dev, enum i2s_dir dir, struct i2s_config *cfg);

const void * i2s_get(uint8_t idx) {
    return embserve_i2s_get_impl(SERVICE_NAME, idx);
}

int i2s_configure(const void *dev, enum i2s_dir dir, struct i2s_config *cfg) {
    return embserve_i2s_configure_impl(SERVICE_NAME, dev, dir, cfg);
}
