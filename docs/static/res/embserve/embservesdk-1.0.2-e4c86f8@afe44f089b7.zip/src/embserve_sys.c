#include "../include/embserve_sys.h"

#include <stdarg.h>

#ifndef SERVICE_NAME
#error "Define SERVICE_NAME"
#endif

extern int embserve_sleep_impl(const char * tag, uint32_t millis);
extern int embserve_printf_impl(const char * tag, const char * format, va_list args);
extern int embserve_puts_impl(const char * tag, const char* str);

int sleep(uint32_t millis) {
    return embserve_sleep_impl(SERVICE_NAME, millis);
}

int printf(const char * format, ...) {
    int ret;

    va_list args;
    va_start(args, format);
    
    //Forward data to embserve API with the service tag 
    ret = embserve_printf_impl(SERVICE_NAME, format, args);

    va_end(args);
    return ret;
}

int puts(const char * str) {
    //Forward data to embserve API with the service tag 
    return embserve_puts_impl(SERVICE_NAME, str);
}