#include "../include/tinyml.h"

#ifndef SERVICE_NAME
#error "Define SERVICE_NAME"
#endif

extern const void * embserve_tinyml_model_load(const char * tag, const uint8_t * model_buf, uint32_t size, uint32_t tensor_arena_size);

const void * tinyml_model_load(const uint8_t * model_buf, uint32_t size, uint32_t tensor_arena_size) {
    return embserve_tinyml_model_load(SERVICE_NAME, model_buf, size, tensor_arena_size);
}