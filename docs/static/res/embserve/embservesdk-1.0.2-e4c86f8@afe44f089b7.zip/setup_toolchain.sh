#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

setup_udynlink() {
    echo "Setting udynlink-ng"

    pushd toolchain/udynlink-ng > /dev/null
    python3 -m pip install -r requirements.txt -q
    popd > /dev/null
}

setup_zephyr() {
    echo "Setting Zephyr toolchain"

    mkdir toolchain/zephyr
    pushd toolchain/zephyr > /dev/null

    # Download
    echo "Downloading zephyr-sdk-0.16.1_linux-x86_64.tar.xz"
    wget https://github.com/zephyrproject-rtos/sdk-ng/releases/download/v0.16.1/zephyr-sdk-0.16.1_linux-x86_64.tar.xz -q --show-progress

    # Verify
    wget -O - https://github.com/zephyrproject-rtos/sdk-ng/releases/download/v0.16.1/sha256.sum -q | shasum --check --ignore-missing

    # Extract
    echo "Extracting zephyr-sdk-0.16.1_linux-x86_64.tar.xz"
    tar xvf zephyr-sdk-0.16.1_linux-x86_64.tar.xz

    # Init Zephyr SDK
    echo "Running setup..."
    ./zephyr-sdk-0.16.1/setup.sh -t arm-zephyr-eabi -h 

    # Cleanup
    rm zephyr-sdk-0.16.1_linux-x86_64.tar.xz

    echo "Done"
    popd > /dev/null

    echo "Please run: \"export ZEPHYR_SDK_PATH=$SCRIPT_DIR/toolchain/zephyr/zephyr-sdk-0.16.1\" before using the toolchain"
}

setup_udynlink
setup_zephyr