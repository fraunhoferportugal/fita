#ifndef FCNTL_API_H
#define FCNTL_API_H

#define O_ACCMODE (O_RDONLY | O_WRONLY | O_RDWR)

#define O_RDONLY 00
#define O_WRONLY 01
#define O_RDWR	 02

#define O_APPEND   0x0400
#define O_EXCL	   0x0800
#define O_NONBLOCK 0x4000

#define F_DUPFD 0
#define F_GETFL 3
#define F_SETFL 4

int fcntl(int fildes, int cmd, ...);

#endif /* FCNTL_API_H */