#ifndef EMBSERVE_SYS_H__
#define EMBSERVE_SYS_H__

#include <stdint.h>

// System APIs
int sleep(uint32_t millis);
void yield(void);

// Time APIs
uint32_t uptime_ms(void);

// Random number generator
uint32_t rand32(void);

#endif // EMBSERVE_SYS_H__