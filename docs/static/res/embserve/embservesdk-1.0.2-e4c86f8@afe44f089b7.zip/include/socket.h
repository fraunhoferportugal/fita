#ifndef SOCKET_API_H
#define SOCKET_API_H

#include <stdint.h>
#include <stdio.h>

/* Thin Socket wrapper. Some functions are missing:
    - Only IPv4
    - Not available:
        - int socketpair(int family, int type, int proto, int sv[2])
        - ssize_t sendmsg(int sock, const struct msghdr *message, int flags)
        - int poll(struct zsock_pollfd *fds, int nfds, int timeout)
        - int getsockopt(int sock, int level, int optname,
        - int getpeername(int sock, struct sockaddr *addr, socklen_t *addrlen)
        - int getsockname(int sock, struct sockaddr *addr, socklen_t *addrlen)
        - int getaddrinfo(const char *host, const char *service, const struct zsock_addrinfo *hints, struct - zsock_addrinfo **res)
        - void freeaddrinfo(struct zsock_addrinfo *ai)
        - int getnameinfo(const struct sockaddr *addr, socklen_t addrlen, char *host, socklen_t hostlen, - char *serv, socklen_t servlen, int flags)
        - int gethostname(char *buf, size_t len)
*/

/* Protocol families. */
#define PF_UNSPEC 0      /**< Unspecified protocol family.  */
#define PF_INET 1        /**< IP protocol family version 4. */
#define PF_INET6 2       /**< IP protocol family version 6. */
#define PF_PACKET 3      /**< Packet family.                */
#define PF_CAN 4         /**< Controller Area Network.      */
#define PF_NET_MGMT 5    /**< Network management info.      */
#define PF_LOCAL 6       /**< Inter-process communication   */
#define PF_UNIX PF_LOCAL /**< Inter-process communication   */

/* Address families. */
#define AF_UNSPEC PF_UNSPEC     /**< Unspecified address family.   */
#define AF_INET PF_INET         /**< IP protocol family version 4. */
#define AF_INET6 PF_INET6       /**< IP protocol family version 6. */
#define AF_PACKET PF_PACKET     /**< Packet family.                */
#define AF_CAN PF_CAN           /**< Controller Area Network.      */
#define AF_NET_MGMT PF_NET_MGMT /**< Network management info.      */
#define AF_LOCAL PF_LOCAL       /**< Inter-process communication   */
#define AF_UNIX PF_UNIX         /**< Inter-process communication   */

#define INADDR_ANY 0

/* Well-known values, e.g. from Linux man 2 shutdown:
 * "The constants SHUT_RD, SHUT_WR, SHUT_RDWR have the value 0, 1, 2,
 * respectively". Some software uses numeric values.
 */
/** shutdown: Shut down for reading */
#define SHUT_RD 0
/** shutdown: Shut down for writing */
#define SHUT_WR 1
/** shutdown: Shut down for both reading and writing */
#define SHUT_RDWR 2

/** Protocol numbers from IANA/BSD */
enum net_ip_protocol {
    IPPROTO_IP = 0,      /**< IP protocol (pseudo-val for setsockopt() */
    IPPROTO_ICMP = 1,    /**< ICMP protocol   */
    IPPROTO_IGMP = 2,    /**< IGMP protocol   */
    IPPROTO_IPIP = 4,    /**< IPIP tunnels    */
    IPPROTO_TCP = 6,     /**< TCP protocol    */
    IPPROTO_UDP = 17,    /**< UDP protocol    */
    IPPROTO_IPV6 = 41,   /**< IPv6 protocol   */
    IPPROTO_ICMPV6 = 58, /**< ICMPv6 protocol */
    IPPROTO_RAW = 255,   /**< RAW IP packets  */
};

/** Socket type */
enum net_sock_type {
    SOCK_STREAM = 1, /**< Stream socket type   */
    SOCK_DGRAM,      /**< Datagram socket type */
    SOCK_RAW         /**< RAW socket type      */
};

typedef _ssize_t ssize_t;

/** Socket address family type */
typedef unsigned short int sa_family_t;

/** Length of a socket address */
typedef size_t socklen_t;

/** Socket port type */
typedef uint16_t in_port_t;

/** Generic sockaddr struct. Must be cast to proper type. */
struct sockaddr {
    uint8_t sa_len;
    int sa_family;
    char sa_data[];
};

/** IPv4 address struct */
struct in_addr {
    union {
        uint8_t s4_addr[4];
        uint16_t s4_addr16[2]; /* In big endian */
        uint32_t s4_addr32[1]; /* In big endian */
        uint32_t s_addr;       /* In big endian, for POSIX compatibility. */
    };
};

/** Socket address struct for IPv4. */
struct sockaddr_in {
    sa_family_t sin_family;  /* AF_INET      */
    uint16_t sin_port;       /* Port number  */
    struct in_addr sin_addr; /* IPv4 address */
};

/**
 * @brief Create a network socket
 *
 * @details
 * See `POSIX.1-2017 article
 * <http://pubs.opengroup.org/onlinepubs/9699919799/functions/socket.html>`__
 * for normative description.
 */
int socket(int domain, int type, int protocol);

/**
 * @brief Close a network socket
 *
 * @details
 * Close a network socket.
 */
int close(int sock);

/**
 * @brief Shutdown socket send/receive operations
 *
 * @details
 * See `POSIX.1-2017 article
 * <http://pubs.opengroup.org/onlinepubs/9699919799/functions/shutdown.html>`__
 * for normative description, but currently this function has no effect in
 * Zephyr and provided solely for compatibility with existing code.
 */
int shutdown(int sock, int how);

/**
 * @brief Bind a socket to a local network address
 *
 * @details
 * See `POSIX.1-2017 article
 * <http://pubs.opengroup.org/onlinepubs/9699919799/functions/bind.html>`__
 * for normative description.
 */
int bind(int socket, const struct sockaddr *address, socklen_t address_len);

/**
 * @brief Connect a socket to a peer network address
 *
 * @details
 * See `POSIX.1-2017 article
 * <http://pubs.opengroup.org/onlinepubs/9699919799/functions/connect.html>`__
 * for normative description.
 */
int connect(int socket, const struct sockaddr *address, socklen_t address_len);

/**
 * @brief Set up a STREAM socket to accept peer connections
 *
 * @details
 * See `POSIX.1-2017 article
 * <http://pubs.opengroup.org/onlinepubs/9699919799/functions/listen.html>`__
 * for normative description.
 */
int listen(int socket, int backlog);

/**
 * @brief Accept a connection on listening socket
 *
 * @details
 * See `POSIX.1-2017 article
 * <http://pubs.opengroup.org/onlinepubs/9699919799/functions/accept.html>`__
 * for normative description.
 */
int accept(int socket, struct sockaddr *address, socklen_t *address_len);

/**
 * @brief Send data to an arbitrary network address
 *
 * @details
 * See `POSIX.1-2017 article
 * <http://pubs.opengroup.org/onlinepubs/9699919799/functions/sendto.html>`__
 * for normative description.
 */
ssize_t sendto(int socket, const void *message, size_t length, int flags, const struct sockaddr *dest_addr, socklen_t dest_len);

/**
 * @brief Send data to a connected peer
 *
 * @details
 * See `POSIX.1-2017 article
 * <http://pubs.opengroup.org/onlinepubs/9699919799/functions/send.html>`__
 * for normative description.
 */
ssize_t send(int socket, const void *buffer, size_t length, int flags);

/**
 * @brief Receive data from an arbitrary network address
 *
 * @details
 * See `POSIX.1-2017 article
 * <http://pubs.opengroup.org/onlinepubs/9699919799/functions/recvfrom.html>`__
 * for normative description.
 */
ssize_t recvfrom(int socket, void *buffer, size_t length, int flags, struct sockaddr *address, socklen_t *address_len);

/**
 * @brief Receive data from a connected peer
 *
 * @details
 * See `POSIX.1-2017 article
 * <http://pubs.opengroup.org/onlinepubs/9699919799/functions/recv.html>`__
 * for normative description.
 */
ssize_t recv(int socket, void *buffer, size_t length, int flags);

/**
 * @brief Get various socket options
 *
 * @details
 * See `POSIX.1-2017 article
 * <http://pubs.opengroup.org/onlinepubs/9699919799/functions/getsockopt.html>`__
 * for normative description. In Zephyr this function supports a subset of
 * socket options described by POSIX, but also some additional options
 * available in Linux (some options are dummy and provided to ease porting
 * of existing code).
 */
int getsockopt(int sock, int level, int optname, void *optval, socklen_t *optlen);

/**
 * @brief Set various socket options
 *
 * @details
 * See `POSIX.1-2017 article
 * <http://pubs.opengroup.org/onlinepubs/9699919799/functions/setsockopt.html>`__
 * for normative description. In Zephyr this function supports a subset of
 * socket options described by POSIX, but also some additional options
 * available in Linux (some options are dummy and provided to ease porting
 * of existing code).
 */
int setsockopt(int sock, int level, int optname, const void *optval, socklen_t optlen);

/**
 * @brief Convert network address from internal to numeric ASCII form
 *
 * @details
 * See `POSIX.1-2017 article
 * <http://pubs.opengroup.org/onlinepubs/9699919799/functions/inet_ntop.html>`__
 * for normative description.
 */
char *inet_ntop(sa_family_t family, const void *src, char *dst, size_t size);

/**
 * @brief Convert network address from numeric ASCII form to internal representation
 *
 * @details
 * See `POSIX.1-2017 article
 * <http://pubs.opengroup.org/onlinepubs/9699919799/functions/inet_pton.html>`__
 * for normative description.
 */
int inet_pton(sa_family_t family, const char *src, void *dst);

/*************************************************************************************
 * net_ip helpers
 *************************************************************************************/
/** @brief Convert 16-bit value from network to host byte order.
 *
 * @param x The network byte order value to convert.
 *
 * @return Host byte order value.
 */
uint16_t ntohs(uint16_t x);

/** @brief Convert 32-bit value from network to host byte order.
 *
 * @param x The network byte order value to convert.
 *
 * @return Host byte order value.
 */
uint32_t ntohl(uint32_t x);

/** @brief Convert 16-bit value from host to network byte order.
 *
 * @param x The host byte order value to convert.
 *
 * @return Network byte order value.
 */
uint16_t htons(uint16_t x);

/** @brief Convert 32-bit value from host to network byte order.
 *
 * @param x The host byte order value to convert.
 *
 * @return Network byte order value.
 */
uint32_t htonl(uint32_t x);

/*************************************************************************************
 * Socket options for SOL_SOCKET level
 *************************************************************************************/
/** sockopt: Socket-level option */
#define SOL_SOCKET 1

/** sockopt: Recording debugging information (ignored, for compatibility) */
#define SO_DEBUG 1
/** sockopt: address reuse (ignored, for compatibility) */
#define SO_REUSEADDR 2
/** sockopt: Type of the socket */
#define SO_TYPE 3
/** sockopt: Async error (ignored, for compatibility) */
#define SO_ERROR 4
/** sockopt: Bypass normal routing and send directly to host (ignored, for compatibility) */
#define SO_DONTROUTE 5
/** sockopt: Transmission of broadcast messages is supported (ignored, for compatibility) */
#define SO_BROADCAST 6

/** sockopt: Size of socket socket send buffer (ignored, for compatibility) */
#define SO_SNDBUF 7
/** sockopt: Size of socket recv buffer */
#define SO_RCVBUF 8

/** sockopt: Enable sending keep-alive messages on connections (ignored, for compatibility) */
#define SO_KEEPALIVE 9
/** sockopt: Place out-of-band data into receive stream (ignored, for compatibility) */
#define SO_OOBINLINE 10
/** sockopt: Socket lingers on close (ignored, for compatibility) */
#define SO_LINGER 13
/** sockopt: Allow multiple sockets to reuse a single port (ignored, for compatibility) */
#define SO_REUSEPORT 15

/** sockopt: Receive low watermark (ignored, for compatibility) */
#define SO_RCVLOWAT 18
/** sockopt: Send low watermark (ignored, for compatibility) */
#define SO_SNDLOWAT 19

/**
 * sockopt: Receive timeout
 * Applies to receive functions like recv(), but not to connect()
 */
#define SO_RCVTIMEO 20
/** sockopt: Send timeout */
#define SO_SNDTIMEO 21

/** sockopt: Bind a socket to an interface */
#define SO_BINDTODEVICE	25

/** sockopt: Socket accepts incoming connections (ignored, for compatibility) */
#define SO_ACCEPTCONN 30

/** sockopt: Timestamp TX packets */
#define SO_TIMESTAMPING 37
/** sockopt: Protocol used with the socket */
#define SO_PROTOCOL 38

/** sockopt: Domain used with SOCKET (ignored, for compatibility) */
#define SO_DOMAIN 39

#endif /* SOCKET_API_H */