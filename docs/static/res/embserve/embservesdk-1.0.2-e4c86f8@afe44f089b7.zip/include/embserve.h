#ifndef EMBSERVE_H__
#define EMBSERVE_H__

#define EMBSERVE_SDK_API 2

#include <stdint.h>
#include <stdbool.h>

//embServe Modules
#include "embserve_sys.h"
#include "embserve_sensor.h"

#define EMBSERVE_MAX_KEY_SIZE 32

typedef enum {
    EMBSERVE_INT = 0,
    EMBSERVE_FLOAT,
    EMBSERVE_BOOL,
    EMBSERVE_BYTE,
} embserve_io_type_t;

typedef struct __attribute__((aligned(4))) {
    char key[EMBSERVE_MAX_KEY_SIZE];
    embserve_io_type_t type;
    void * data;
    uint32_t data_len;
} embserve_io_t;

//Entry/Exit points
int setup(void);
void loop(void);
void on_quit(void);
void on_input(embserve_io_t * input);

//API to send outputs
void embserve_output(embserve_io_t * output);

#endif  // EMBSERVE_H__