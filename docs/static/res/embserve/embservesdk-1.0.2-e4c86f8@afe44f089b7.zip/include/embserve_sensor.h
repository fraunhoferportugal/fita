#ifndef EMBSERVE_SENSOR_H__
#define EMBSERVE_SENSOR_H__

#define SENSOR_VALUES_MAX 3

#include <stdint.h>

typedef enum {
    SENSOR_ACCELEROMETER = 0,
    SENSOR_GYROSCOPE,
    SENSOR_MAGNETOMETER,
    SENSOR_TEMPERATURE,
    SENSOR_HUMIDITY,
} embserve_sensor_type_t;

typedef struct {
    embserve_sensor_type_t type;
    uint32_t timestamp;
    uint8_t len;
    float values[SENSOR_VALUES_MAX];
} embserve_sensor_data_t;

int embserve_get_sensor(embserve_sensor_type_t type, int * sensor_id);
int embserve_get_sensor_data(int sensor_id, embserve_sensor_data_t * sensor_data);

#endif // EMBSERVE_SENSOR_H__