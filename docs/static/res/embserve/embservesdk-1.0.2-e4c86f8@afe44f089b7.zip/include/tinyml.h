#ifndef TINYML_H__
#define TINYML_H__

#include <stdint.h>
#include <stdbool.h>

enum tinyml_tensor_type {
    NoType = 0,
    Float32 = 1,
    Int32 = 2,
    UInt8 = 3,
    Int64 = 4,
    String = 5,
    Bool = 6,
    Int16 = 7,
    // Complex64 = 8,
    Int8 = 9,
    Float16 = 10,
    Float64 = 11,
    // Complex128 = 12,
    UInt64 = 13,
    // Resource = 14,
    // Variant = 15,
    UInt32 = 16,
};

enum tinyml_quantization_type {
    NoQuantization = 0,
    AffineQuantization = 1,
};

struct tinyml_quantization_params {
    float scale;
    int32_t zero_point;
};

struct tinyml_tensor {
    uint32_t size;
    enum tinyml_tensor_type type;
    void * data;
    
    enum tinyml_quantization_type quantization_type;
    struct tinyml_quantization_params quantization_params;
};

const void * tinyml_model_load(const uint8_t * model_buf, uint32_t size, uint32_t tensor_arena_size);
int tinyml_model_tensor_info(const void * model, bool output, uint32_t index, struct tinyml_tensor * tensor);
int tinyml_model_input(const void * model, uint32_t index, const struct tinyml_tensor * tensor);
int tinyml_model_output(const void * model, uint32_t index, struct tinyml_tensor * tensor);
int tinyml_model_invoke(const void * model);
int tinyml_model_unload(const void * model);

#endif // TINYML_H__